package com.gml.cursomc.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
public class Log implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idLog;
    private Integer status;
    private String  msg;


    @Column(updatable=false)
    @CreationTimestamp
    private Date created;

    @UpdateTimestamp
    private Date updated;

    public Log(Integer status, String msg) {
        this.status = status;
        this.msg = msg;
        this.updated = updated;
    }

    public Integer getIdLog() {
        return idLog;
    }

    public void setIdLog(Integer idLog) {
        this.idLog = idLog;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Date getTimeStamp() {
        return updated;
    }

    public void setTimeStamp(Date timeStamp) {
        this.updated = timeStamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Log)) return false;
        Log log = (Log) o;
        return Objects.equals(getIdLog(), log.getIdLog()) &&
                Objects.equals(getStatus(), log.getStatus()) &&
                Objects.equals(getMsg(), log.getMsg()) &&
                Objects.equals(getTimeStamp(), log.getTimeStamp());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getIdLog(), getStatus(), getMsg(), getTimeStamp());
    }

    @Override
    public String toString() {
        return "Log{" +
                "idLog=" + idLog +
                ", status=" + status +
                ", msg='" + msg + '\'' +
                ", timeStamp=" + updated +
                '}';
    }
}
