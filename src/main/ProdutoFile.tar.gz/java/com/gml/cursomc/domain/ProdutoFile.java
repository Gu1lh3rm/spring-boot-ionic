package com.gml.cursomc.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
public class ProdutoFile implements Serializable {
    private static final long serialVersionUID =1L;

    @JsonIgnore
    @EmbeddedId
    private ProdutoFilePK id = new ProdutoFilePK();

    public ProdutoFile() {
    }

    public ProdutoFile(File file, Produto produto) {
        super();
        id.setFile(file);
        id.setProduto(produto);
    }

    @JsonIgnore
    public ProdutoFilePK getId() {
        return id;
    }

    public void setId(ProdutoFilePK id) {
        this.id = id;
    }

    public File getFile() {
        return id.getFile();
    }

    public Produto getProduto() {
        return id.getProduto();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ProdutoFile)) return false;
        ProdutoFile that = (ProdutoFile) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id);
    }

}
